import java.awt.Point;

public class Main {

	public static void main(String args[]) {

		Board board = Board.getInstance();
		board.createBoard();
		board.setBasePos(new Point(board.m.length / 2, board.m.length / 2));
		ReactiveAgent agent = new ReactiveAgent("R");
		ReactiveAgent agent2 = new ReactiveAgent("T");
		ReactiveAgent agent3 = new ReactiveAgent("U");
		ReactiveAgent agent4 = new ReactiveAgent("V");
		ReactiveAgent agent5 = new ReactiveAgent("W");
		ReactiveAgent agent6 = new ReactiveAgent("X");
		ReactiveAgent agent7 = new ReactiveAgent("Y");
		ReactiveAgent agent8 = new ReactiveAgent("Z");
		agent.setCurrPos(new Point(board.m.length / 2 - 1, board.m.length / 2 - 1));
		agent2.setCurrPos(new Point(board.m.length / 2 - 1, board.m.length / 2 + 1));
		agent3.setCurrPos(new Point(board.m.length / 2 + 1, board.m.length / 2 - 1));
		agent4.setCurrPos(new Point(board.m.length / 2 + 1, board.m.length / 2 + 1));
		agent5.setCurrPos(new Point(board.m.length / 2 , board.m.length / 2 + 1));
		agent6.setCurrPos(new Point(board.m.length / 2 , board.m.length / 2 - 1));
		agent7.setCurrPos(new Point(board.m.length / 2 - 1, board.m.length / 2 ));
		agent8.setCurrPos(new Point(board.m.length / 2 + 1, board.m.length / 2 ));
		board.setAgentPos(agent);
		board.setAgentPos(agent2);
		board.setAgentPos(agent3);
		board.setAgentPos(agent4);
		board.setAgentPos(agent5);
		board.setAgentPos(agent6);
		board.setAgentPos(agent7);
		board.setAgentPos(agent8);
		board.printBoard();

		while (board.hasRocks()) { // || !agent2.isAgentAtTheBase() || !agent3.isAgentAtTheBase() || !agent4.isAgentAtTheBase()) {
			if (agent.hasFoundRock()){
				agent.moveToBase();
			}
			else {
				agent.move();
			}
			if (!board.hasRocks())
				break;
			if (agent2.hasFoundRock()){
				agent2.moveToBase();
			}
			else {
				agent2.move();
			}
			if (!board.hasRocks())
				break;
			if (agent3.hasFoundRock()){
				agent3.moveToBase();
			}
			else {
				agent3.move();
			}
			if (!board.hasRocks())
				break;
			if (agent4.hasFoundRock()){
				agent4.moveToBase();
			}
			else {
				agent4.move();
			}
			if (!board.hasRocks())
				break;
			if (agent5.hasFoundRock()){
				agent5.moveToBase();
			}
			else {
				agent5.move();
			}
			if (!board.hasRocks())
				break;
			if (agent6.hasFoundRock()){
				agent6.moveToBase();
			}
			else {
				agent6.move();
			}
			if (!board.hasRocks())
				break;
			if (agent7.hasFoundRock()){
				agent7.moveToBase();
			}
			else {
				agent7.move();
			}
			if (!board.hasRocks())
				break;
			if (agent8.hasFoundRock()){
				agent8.moveToBase();
			}
			else {
				agent8.move();
			}
			board.printBoard();
			try {
				Thread.sleep(2000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		
		System.out.println("All rocks collected! Well done agents!");
	}
}